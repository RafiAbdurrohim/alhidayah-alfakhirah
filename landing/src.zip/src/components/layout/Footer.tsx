"use client";

import { useTranslations } from "next-intl";
import { SOCIAL_LINKS, CONTACT_INFO } from "@/lib/utils";
import { Instagram, Facebook, Twitter, MessageCircle } from "lucide-react";

export function Footer() {
  const t = useTranslations();

  const socialIcons = {
    instagram: Instagram,
    facebook: Facebook,
    twitter: Twitter,
    whatsapp: MessageCircle, // Add this
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center text-white font-bold text-xl">A</div>
              <span className="font-bold text-xl text-white">{t("common.appName")}</span>
            </div>
            <p className="text-sm text-gray-400 mb-4">{t("footer.description")}</p>
            <div className="flex gap-4">
              {Object.entries(SOCIAL_LINKS)
                .slice(0, 3)
                .map(([key, url]) => {
                  const Icon = socialIcons[key as keyof typeof socialIcons];
                  return (
                    <a key={key} href={url} target="_blank" rel="noopener noreferrer" className="h-10 w-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-primary transition-colors">
                      <Icon className="h-5 w-5" />
                    </a>
                  );
                })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">{t("footer.quickLinks")}</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  {t("footer.aboutUs")}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  {t("footer.faq")}
                </a>
              </li>
              <li>
                <a href="#privacy" className="hover:text-white transition-colors">
                  {t("footer.privacyPolicy")}
                </a>
              </li>
              <li>
                <a href="#terms" className="hover:text-white transition-colors">
                  {t("footer.termsOfService")}
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-white mb-4">{t("common.contactUs")}</h3>
            <ul className="space-y-2 text-sm">
              <li>{CONTACT_INFO.phone}</li>
              <li>{CONTACT_INFO.email}</li>
              <li>{CONTACT_INFO.address}</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
          <p>{t("footer.copyright")}</p>
          <p className="mt-2 text-gray-500">{t("footer.madeWith")}</p>
        </div>
      </div>
    </footer>
  );
}
