'use client';

import { useTranslations } from 'next-intl';

export function HowItWorksSection() {
  const t = useTranslations();

  const steps = [
    { number: '1', title: t('howItWorks.step1.title'), description: t('howItWorks.step1.description') },
    { number: '2', title: t('howItWorks.step2.title'), description: t('howItWorks.step2.description') },
    { number: '3', title: t('howItWorks.step3.title'), description: t('howItWorks.step3.description') },
    { number: '4', title: t('howItWorks.step4.title'), description: t('howItWorks.step4.description') },
  ];

  return (
    <section className="py-20 bg-accent/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">{t('howItWorks.title')}</h2>
          <p className="text-lg text-muted-foreground">{t('howItWorks.subtitle')}</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="h-16 w-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
