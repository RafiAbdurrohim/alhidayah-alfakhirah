'use client';

import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/Button';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { CONTACT_INFO } from '@/lib/utils';

export function ContactSection() {
  const t = useTranslations();

  return (
    <section id="contact" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">{t('contact.title')}</h2>
          <p className="text-lg text-muted-foreground">{t('contact.subtitle')}</p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('contact.address')}</h3>
                <p className="text-muted-foreground">{CONTACT_INFO.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('contact.phone')}</h3>
                <p className="text-muted-foreground">{CONTACT_INFO.phone}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('contact.email')}</h3>
                <p className="text-muted-foreground">{CONTACT_INFO.email}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('contact.hours')}</h3>
                <p className="text-muted-foreground">{t('contact.dailyHours')}</p>
              </div>
            </div>
          </div>

          {/* Contact Form Placeholder */}
          <div className="bg-gray-50 p-8 rounded-2xl">
            <form className="space-y-4">
              <input
                type="text"
                placeholder={t('contact.name')}
                className="w-full px-4 py-3 rounded-lg border focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <input
                type="email"
                placeholder={t('contact.email')}
                className="w-full px-4 py-3 rounded-lg border focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <textarea
                placeholder={t('contact.message')}
                rows={4}
                className="w-full px-4 py-3 rounded-lg border focus:outline-none focus:ring-2 focus:ring-primary"
              ></textarea>
              <Button type="submit" className="w-full">{t('contact.send')}</Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
