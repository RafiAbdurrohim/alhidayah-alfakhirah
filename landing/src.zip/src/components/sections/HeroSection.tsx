"use client";

import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/Button";
import { ArrowRight, Download } from "lucide-react";

export function HeroSection() {
  const t = useTranslations();

  return (
    <section id="hero" className="relative bg-gradient-to-br from-primary/5 via-accent/20 to-background py-12 lg:py-16">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="space-y-6 animate-fade-in">
            <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
              {t("hero.title")}
              <br />
              <span className="text-primary">{t("hero.subtitle")}</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl">{t("hero.description")}</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="gap-2">
                <Download className="h-5 w-5" />
                {t("hero.orderNow")}
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                {t("hero.viewMenu")}
                <ArrowRight className="h-5 w-5" />
              </Button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-8">
              <div>
                <div className="text-3xl font-bold text-primary">1000+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">50+</div>
                <div className="text-sm text-muted-foreground">Menu Items</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">30min</div>
                <div className="text-sm text-muted-foreground">Fast Delivery</div>
              </div>
            </div>
          </div>

          {/* Image Placeholder */}
          <div className="relative animate-slide-in-right">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://static.wixstatic.com/media/aa51fb_9a25bc1dc25d45f5a4bdd43c340d8dfd~mv2.jpg/v1/fill/w_864,h_621,al_c,q_85,enc_avif,quality_auto/aa51fb_9a25bc1dc25d45f5a4bdd43c340d8dfd~mv2.jpg"
                alt="Delicious Arabic cuisine"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating Cards */}
            <div className="absolute -bottom-4 -left-4 bg-white p-4 rounded-xl shadow-lg">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 bg-success/20 rounded-full flex items-center justify-center">⭐</div>
                <div>
                  <div className="font-bold">4.9/5.0</div>
                  <div className="text-xs text-muted-foreground">Customer Rating</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
