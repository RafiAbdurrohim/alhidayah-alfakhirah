"use client";

import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/Button";
import { CheckCircle } from "lucide-react";

export function DriverSection() {
  const t = useTranslations();

  return (
    <section className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">{t("driver.title")}</h2>
            <h3 className="text-xl mb-6">{t("driver.subtitle")}</h3>
            <p className="text-lg mb-8 opacity-90">{t("driver.description")}</p>
            <div className="space-y-3 mb-8">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6" />
                <span>{t("driver.benefits.flexible")}</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6" />
                <span>{t("driver.benefits.competitive")}</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6" />
                <span>{t("driver.benefits.bonuses")}</span>
              </div>
            </div>
            <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-gray-100">
              {t("driver.applyNow")}
            </Button>
          </div>
          <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://www.shutterstock.com/shutterstock/photos/2629357801/display_1500/stock-vector-after-customer-confirms-order-on-application-on-their-mobile-phone-a-green-motorcycle-or-scooter-2629357801.jpg"
              alt="Join our delivery team"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
