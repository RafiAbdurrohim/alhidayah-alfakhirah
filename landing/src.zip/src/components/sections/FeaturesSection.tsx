'use client';

import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Zap, ShoppingBag, Smartphone, Shield } from 'lucide-react';

export function FeaturesSection() {
  const t = useTranslations();

  const features = [
    {
      icon: Zap,
      title: t('features.fastDelivery.title'),
      description: t('features.fastDelivery.description'),
      color: 'text-warning',
    },
    {
      icon: ShoppingBag,
      title: t('features.wideSelection.title'),
      description: t('features.wideSelection.description'),
      color: 'text-success',
    },
    {
      icon: Smartphone,
      title: t('features.easyOrdering.title'),
      description: t('features.easyOrdering.description'),
      color: 'text-primary',
    },
    {
      icon: Shield,
      title: t('features.securePayment.title'),
      description: t('features.securePayment.description'),
      color: 'text-danger',
    },
  ];

  return (
    <section id="features" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            {t('features.title')}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t('features.subtitle')}
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="hover:shadow-lg transition-shadow duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader>
                  <div className={`h-12 w-12 rounded-lg bg-${feature.color}/10 flex items-center justify-center mb-4`}>
                    <Icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
