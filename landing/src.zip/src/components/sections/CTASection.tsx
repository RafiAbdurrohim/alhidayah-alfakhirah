'use client';

import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/Button';
import { Apple, Play } from 'lucide-react';

export function CTASection() {
  const t = useTranslations();

  return (
    <section className="py-20 bg-gradient-to-r from-primary to-primary-dark text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl lg:text-4xl font-bold mb-4">{t('cta.downloadTitle')}</h2>
        <p className="text-lg mb-8 opacity-90">{t('cta.downloadSubtitle')}</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-gray-100 gap-2">
            <Apple className="h-6 w-6" />
            <div className="text-left">
              <div className="text-xs">Download on the</div>
              <div className="font-semibold">App Store</div>
            </div>
          </Button>
          <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-gray-100 gap-2">
            <Play className="h-6 w-6" />
            <div className="text-left">
              <div className="text-xs">Get it on</div>
              <div className="font-semibold">Google Play</div>
            </div>
          </Button>
        </div>
      </div>
    </section>
  );
}
